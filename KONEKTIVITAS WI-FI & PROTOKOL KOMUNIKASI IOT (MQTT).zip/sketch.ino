
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// =====================================
// KONFIGURASI PIN DAN SENSOR
// =====================================
#define DHTPIN 15
#define DHTTYPE DHT22
#define LED_PIN 2

DHT dht(DHTPIN, DHTTYPE);

// =====================================
// KONFIGURASI WIFI WOKWI
// =====================================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// =====================================
// KONFIGURASI MQTT BROKER
// =====================================
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

// =====================================
// TOPIK MQTT
// =====================================
const char* topic_suhu = "iot/pelatihan/vano/suhu";
const char* topic_lembap = "iot/pelatihan/vano/kelembapan";
const char* topic_lampu = "iot/pelatihan/vano/lampu";

// =====================================
// INISIALISASI WIFI DAN MQTT
// =====================================
WiFiClient espClient;
PubSubClient client(espClient);

unsigned long lastMsg = 0;

// =====================================
// FUNGSI MENGHUBUNGKAN WIFI
// =====================================
void setup_wifi() {
  delay(10);

  Serial.print("Menghubungkan ke Wi-Fi: ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("Wi-Fi Terhubung!");

  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

// =====================================
// FUNGSI CALLBACK MQTT
// MENERIMA PERINTAH LED ON/OFF
// =====================================
void callback(char* topic, byte* payload, unsigned int length) {
  String pesan = "";

  for (unsigned int i = 0; i < length; i++) {
    pesan += (char)payload[i];
  }

  Serial.print("Pesan masuk [");
  Serial.print(topic);
  Serial.print("]: ");
  Serial.println(pesan);

  if (String(topic) == topic_lampu) {
    if (pesan == "ON") {
      digitalWrite(LED_PIN, HIGH);
      Serial.println("LED MENYALA");
    }
    else if (pesan == "OFF") {
      digitalWrite(LED_PIN, LOW);
      Serial.println("LED MATI");
    }
  }
}

// =====================================
// FUNGSI RECONNECT MQTT
// =====================================
void reconnect() {
  while (!client.connected()) {
    Serial.print("Menghubungkan ke MQTT Broker...");

    String clientId = "ESP32Client-";
    clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("Terhubung!");

      client.subscribe(topic_lampu);

      Serial.print("Subscribed ke topik: ");
      Serial.println(topic_lampu);
    }
    else {
      Serial.print("Gagal, rc=");
      Serial.print(client.state());
      Serial.println(" coba lagi dalam 5 detik");

      delay(5000);
    }
  }
}

// =====================================
// FUNGSI SETUP
// =====================================
void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  dht.begin();

  setup_wifi();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  Serial.println("Sistem ESP32 Siap!");
}

// =====================================
// FUNGSI LOOP
// =====================================
void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  unsigned long now = millis();

  // Mengirim data setiap 3 detik
  if (now - lastMsg > 3000) {
    lastMsg = now;

    float kelembapan = dht.readHumidity();
    float suhu = dht.readTemperature();

    if (isnan(kelembapan) || isnan(suhu)) {
      Serial.println("Gagal membaca sensor DHT22!");
      return;
    }

    char strSuhu[8];
    char strLembap[8];

    dtostrf(suhu, 1, 2, strSuhu);
    dtostrf(kelembapan, 1, 2, strLembap);

    // Publish data suhu
    client.publish(topic_suhu, strSuhu);

    // Publish data kelembapan
    client.publish(topic_lembap, strLembap);

    Serial.print("Publish Suhu: ");
    Serial.print(strSuhu);
    Serial.print(" °C | Kelembapan: ");
    Serial.print(strLembap);
    Serial.println(" %");
  }
}
