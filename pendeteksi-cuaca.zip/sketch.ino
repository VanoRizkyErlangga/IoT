
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Definisi Pin dan Tipe Sensor
#define DHTPIN 15
#define DHTTYPE DHT22

// Inisialisasi Sensor DHT22 dan LCD
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  // Inisialisasi Serial Monitor
  Serial.begin(115200);
  Serial.println("=== Stasiun Cuaca Mini ESP32 ===");

  // Inisialisasi komunikasi I2C ESP32
  Wire.begin(21, 22);

  // Inisialisasi Sensor DHT22
  dht.begin();

  // Inisialisasi LCD
  lcd.init();
  lcd.backlight();

  // Tampilan Awal (Splash Screen)
  lcd.setCursor(0, 0);
  lcd.print("IoT Weather Stn");

  lcd.setCursor(0, 1);
  lcd.print("Initializing...");

  delay(2000);
  lcd.clear();
}

void loop() {
  // Jeda pembacaan sensor minimal 2 detik
  delay(2000);

  // Membaca Kelembapan dan Suhu
  float kelembapan = dht.readHumidity();
  float suhu = dht.readTemperature();

  // Validasi Hasil Pembacaan Sensor
  if (isnan(kelembapan) || isnan(suhu)) {
    Serial.println("Gagal membaca data DHT22!");

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Error Sensor!");

    lcd.setCursor(0, 1);
    lcd.print("Cek koneksi DHT");
    return;
  }

  // Cetak Data ke Serial Monitor
  Serial.print("Suhu: ");
  Serial.print(suhu);
  Serial.print(" C | Kelembapan: ");
  Serial.print(kelembapan);
  Serial.println(" %");

  // Tampilkan Suhu pada Baris Pertama LCD
  lcd.setCursor(0, 0);
  lcd.print("Suhu : ");
  lcd.print(suhu, 1);
  lcd.write((byte)223);
  lcd.print("C   ");

  // Tampilkan Kelembapan pada Baris Kedua LCD
  lcd.setCursor(0, 1);
  lcd.print("Lembap: ");
  lcd.print(kelembapan, 1);
  lcd.print("%   ");
}
